const express = require('express')
const Contact = require('../models/Contact')
const router = express.Router()

router.get('/', (req, res) => {
    Contact.find()
    .then(contacts =>{
        console.log(contacts)
        res.json(contacts)
    })
    .catch(err => {
        res.status(501).json({ msg: 'error getting contacts'})
    })
})

router.post('/', (req, res) => {
    
    //console.log(req.body)

    const { email, query, status } = req.body

    const contact = new Contact
    contact.email = email
    contact.query = query
    contact.status = status

    contact.save()
        .then((data) => {
            res.json(data)
            console.log("Post contact routes work")
        })
        .catch(err => res.status(500).json(err))
})

module.exports = router