const express = require('express')
const router = express.Router()
const { loginValidator, registerValidator } = require('../middlewares/userRouteValidator')
const auth = require('../middlewares/authentication')
const User = require('../models/User')
router.post('/login', loginValidator, (req, res) =>{
    const {name, password} = req.body
    User.findOne({ name })
        .then(user=>{
            if(user)
            {
                if(user.comparePasswordHash(password)){
                    res.json(user.generateUserObject())
                }
                else{
                    res.status(401).json({
                        msg: 'Invalid credentials'
                    })
                }
            }
            else{
                res.status(404).json({ msg: 'User not found'})
            }
        })
})

router.post('/register', registerValidator, (req, res) => {
    const { name, password, email, admin } = req.body
    const user = new User()
    user.name = name 
    user.generatePasswordHash(password)
    user.email = email
    user.admin = admin
    user.save()
        .then(newUser =>{
            res.json(newUser)
        }).catch(err => {
            res.status(504).json(err)
        })
})
router.get('/users', (req, res) =>{

    User.find()
        .then(users =>{
            console.log(users)
            res.json(users)
        })
        .catch(err => {
            res.status(501).json({ msg: 'error getting users'})
        })
})
router.get('users/:id', (req, res) =>{
    const {id } = req.params
    User.findById(id)
        .then(task =>res.json(task))
        .catch(err => res.status(502).json(err))
})
module.exports = router