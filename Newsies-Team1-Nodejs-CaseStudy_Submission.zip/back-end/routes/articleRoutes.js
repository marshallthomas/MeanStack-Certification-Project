const express=require('express')
const Article=require('../models/Article')
const router=express.Router()



router.get('/', (req,res)=>{
    console.log('made it here')
    Article.find().sort({published_at:-1}).then(articles =>{
            return res.json(articles)
        })
        .catch(err =>{
            console.log(err)
            return res.status(500).json(err)
        })
})

router.get('/:id',(req,res)=>{
    const {id}=req.params
    console.log(id)
    console.log("this is the get request")
    if(id==='general'){
        Article.find({category:'General'}).sort({published_at:-1}).then(articles =>{
            return res.json(articles)
            console.log(articles)
            })
            .catch(err =>{
                return res.status(500).json({msg:err})
            })
    }
    else if(id==='sports'){
        Article.find({category:'Sports'}).sort({published_at:-1}).then(articles =>{
            return res.json(articles)
            console.log(articles)
            })
            .catch(err =>{
                return res.status(500).json({msg:err})
            })
    }
    else{
    Article.findById(id).then(article =>{
        res.json(article)
        console.log(article)
        })
        .catch(err =>{
            res.status(500).json({msg:err})
        })
    }
})

const auth = require('../middlewares/authentication')

router.use(auth)

router.post('/',(req,res)=>{
    const {title,description,url,url_image,category,published_at} = req.body

    const article=new Article
    article.title=title
    article.description=description
    article.url=url
    article.url_image=url_image
    article.category=category
    article.published_at=published_at

    article.save()
    .then(data=>res.json(data))
    .catch(err=> res.status(500).json(err))
})

router.put('/:id',(req,res)=>{
    const {id}=req.params

    Article.findOneAndUpdate({_id:id},req.body,{new:true,useFindAndModify:false})
    .then(article=> res.json(article))
    .catch(err=>res.status(500).json(err))
 
 })


router.delete('/:id',(req,res)=>{
    const{ id }=req.params
    Article.findByIdAndDelete(id)
    .then(article=> 
        res.json(article))
    .catch(err => 
        res.status(500).json(err))
    })

module.exports=router