const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const articleRoutes = require('./routes/articleRoutes');
const contactRoutes = require('./routes/contactRoutes')
const cors = require('cors');
const mongooseConnectionObject = {
	dbname: 'media_app',
	dbport: 27018,
	localhost: 'mongodb://localhost:'
};
mongoose.connect(
	mongooseConnectionObject.localhost + mongooseConnectionObject.dbport + '/' + mongooseConnectionObject.dbname,
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() =>
		console.log(
			'➢ MongoDB Connected at ' +
				mongooseConnectionObject.localhost +
				' on ' +
				mongooseConnectionObject.dbport +
				'...\nDB: ' +
				mongooseConnectionObject.dbname
		)
);
const userRoutes = require('./routes/userRoutes');

const app = express();
app.use(cors());
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());

app.use((req, res, next) => {
	const { name, password } = req.body;
	console.log('Inside the Middleware' + name + password);
	// res.send('Middleware function')
	next();
});
app.use('/contact', contactRoutes)
app.use('/articles', articleRoutes);
app.use('/', userRoutes);
module.exports = app;
