const http = require('http')
const app = require('./app')

const PORT  = 3000

const server = http.createServer(app)
var io = require('socket.io').listen(server);

var chatmessages = [];
var userList = [];
// Handle socket traffic
io.sockets.on('connection', (socket) => {
	socket.on('username', (data) => {
		io.sockets.emit('chatmessages', chatmessages);
		//console.log('Username: ' + data.username);
		let userModel = {
			socketId: socket.id,
			username: data.username,
			color: data.color
		};

		userList.push(userModel);
		socket.emit('get previous chat', chatmessages);

		io.sockets.emit('userlist', userList);
	});

	socket.on('disconnect', function() {
		//console.log('Got disconnect!');

		let index = 0;
		userList.forEach((data) => {
			if (data.socketId === socket.id) {
				userList.splice(index, 1);
			}
			index++;
		});
		io.sockets.emit('updatelist', userList);
	});

	socket.on('send msg', (data) => {
		chatmessages.push(data);

		io.sockets.emit('send to chat box', chatmessages);
	});
});

// END SOCKET *********************

app.get('/', (req, res) => {});

server.listen(PORT, () => console.log('Server started!' + PORT))