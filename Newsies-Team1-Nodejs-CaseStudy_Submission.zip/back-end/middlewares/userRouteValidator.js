exports.loginValidator = (req, res, next) => {
    const { name, password } = req.body
    let errors = {}
    console.log(name)
    console.log(password)
    if (!name || name === '') errors.name = 'username cannot be blank.'
    if (!password || password === '') errors.password = 'Password cannot be blank.'


    if (Object.keys(errors).length === 0) {
        console.log("The errors are:  ")
        next()
    } else {
        res.status(400).json(errors)
    }
}

exports.registerValidator = (req, res, next) => {
    const { name, password, email, admin } = req.body
    let errors = {}
    console.log(name)
    console.log(password)
    console.log(email)
    console.log(admin)
    if (!name || name === '') errors.name = 'email cannot be blank.'
    if (!email || email === '') errors.email = 'username cannot be blank.'
    if (!password || password === '') errors.password = 'Password cannot be blank.'
    if (!admin || admin === '') errors.admin = 'admin cannot be blank.'

    console.log('Inside Register Validator', req.body)
    if (Object.keys(errors).length === 0) {
        next()
    } else {
        console.log("are there errors?")
        console.log(errors)
        res.status(400).json(errors)
    }
}