const mongoose = require('mongoose')

const ContactSchema = new mongoose.Schema({
    email: { type: String, required: true },
    query: { type: String },
    status: { type: String }
})

const Contact = mongoose.model('Contact', ContactSchema)

module.exports = Contact