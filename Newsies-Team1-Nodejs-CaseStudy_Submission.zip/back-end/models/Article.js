const mongoose=require('mongoose')

const ArticleSchema=new mongoose.Schema({
    title: { type:String, required:true},
    description:{ type: String},
    url: { type: String},
    url_image: { type: String},
    published_at: { type: Date},
    category: {type:String,required:true}
})

const Article=mongoose.model('Article',ArticleSchema)

module.exports= Article