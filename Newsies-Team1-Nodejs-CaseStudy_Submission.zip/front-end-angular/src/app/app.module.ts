import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AgmCoreModule } from '@agm/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { HeaderComponent } from './components/header/header.component';
import { NavComponent } from './components/nav/nav.component';
import { DatePipe } from '@angular/common';
import { FooterComponent } from './components/footer/footer.component';
import { RouterModule, Routes } from '@angular/router'
import { HttpClientModule } from '@angular/common/http';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TestingComponent } from './components/testing/testing.component';
import { ChatboxComponent } from './components/chatbox/chatbox.component';
import { HomeComponent } from './components/home/home.component';
import { ChatHandlerComponent } from './components/chat-handler/chat-handler.component';
import { EditArticleComponent } from './components/edit-article/edit-article.component';
import { ArticlelistComponent } from './components/articlelist/articlelist.component';
import { AddarticleComponent } from './components/addarticle/addarticle.component';
import { SportsNewsComponent } from './components/sports-news/sports-news.component';
import { SearchPipe } from './pipes/search.pipe';
import { AuthGuard } from 'src/app/guards/auth.guard';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component'

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full'},
  { path: 'login', component: LoginComponent},
  { path: 'register', component: RegisterComponent},
  { path: 'home', component: HomeComponent},
  { path: 'add', component: AddarticleComponent, canActivate: [AuthGuard]},
  { path: 'display', component: ArticlelistComponent, canActivate: [AuthGuard]},
  { path: 'sports', component: SportsNewsComponent},
  { path: 'edit/:id', component: EditArticleComponent, canActivate: [AuthGuard]},
  { path: 'aboutus', component: AboutUsComponent },
  { path: 'contactus', component: ContactUsComponent }
]
@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    HeaderComponent,
    NavComponent,
    FooterComponent,
    TestingComponent,
    ChatboxComponent,
    HomeComponent,
    ChatHandlerComponent,
    EditArticleComponent,
    ArticlelistComponent,
    AddarticleComponent,
    SportsNewsComponent,
    SearchPipe,
    AboutUsComponent,
    ContactUsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyDHRJn0nlwdnfGJpNUAyYdFLOWu32iGXIM'
    })
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
