export class User {
    _id: number
    name: String
    password: String
    email: String
    admin: boolean
    constructor (id, name, password, email){
        this._id = id
        this.name = name
        this.email = email
        this.password = password
        this.admin = false
    }
}
