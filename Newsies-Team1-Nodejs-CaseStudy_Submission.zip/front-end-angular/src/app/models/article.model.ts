export class Article {
    _id: string;
    title: string;
    description: string;
    url:string;
    url_image:string;
    category:string;
    published_at: Date;
    

    constructor(title,description,url,url_image,category,published_at) {
        this.title=title;
        this.description=description;
        this.url=url;
        this.url_image=url_image;
        this.category=category;
        this.published_at=published_at;
       
    }
}

