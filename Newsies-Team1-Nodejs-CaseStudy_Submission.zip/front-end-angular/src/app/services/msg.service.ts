import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MsgService {

  subject= new Subject();
  constructor() { }

  getMsg(): Observable<any>{
    return this.subject.asObservable();
  }

  sendMsg(msg){
    this.subject.next(msg)
  }
}
