import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs'
import { map } from 'rxjs/operators'
import { User } from 'src/app/models/user.model'
const loginUrl = 'http://localhost:3000/login'
const registerUrl = 'http://localhost:3000/register'
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }
  login(creds: any): Observable <any> {
    return this.http.post(loginUrl, creds).pipe(map((user) =>{

      localStorage.setItem('user', JSON.stringify(user))
      return user
    }))
  }
  logout(){
    localStorage.removeItem('user')
  }
  getUserDetails(){
    return JSON.parse(localStorage.getItem('user'))
  }
  register(data){
    console.log(data)
    return this.http.post<User>(registerUrl, data)
  }
  // fetchUsers(): Observable<User[]>{
  //   return this.http.get<User[]>(userUrl)
  // }
  // fetchSingleUser(id): Observable<User>{
  //   return this.http.get<User>(userUrl + '/' +id)
  // }
}
