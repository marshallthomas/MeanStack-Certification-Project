import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const weatherUrl='https://api.openweathermap.org/data/2.5/weather?'
const apiKey= 'cd4e9d08d3d0b205147e4057b8f23484'
@Injectable({
  providedIn: 'root'
})
export class WeatherService {
  constructor(private http:HttpClient) { }


  getWeatherData(longitude,latitude): Observable<any>{
    //console.log('Longitude::'+latitude+' Latitude::'+longitude)
    //console.log(weatherUrl+ 'lat=' +latitude +'&lon='+longitude +'&appid=' +apiKey)
    return this.http.get<any>(weatherUrl+ 'lat=' +latitude +'&lon='+longitude +'&appid=' +apiKey);
  }
}
