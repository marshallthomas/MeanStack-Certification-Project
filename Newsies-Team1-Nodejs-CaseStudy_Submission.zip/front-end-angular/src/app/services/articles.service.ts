import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Article } from 'src/app/models/article.model';
import { Observable} from 'rxjs';
import { ThrowStmt } from '@angular/compiler';
import { UserService } from './user.service';

const articleUrl= 'http://localhost:3000/articles'

@Injectable({
  providedIn: 'root'
})
export class ArticlesService {

  constructor(private http:HttpClient, private user: UserService) { }


  addArticle(data): Observable<Article>{
    return this.http.post<Article>(articleUrl, data, {
      headers: {
        authorization: 'Bearer ' + this.user.getUserDetails().token
      }
    })
  }

  getArticles():Observable<Article[]>{
    return this.http.get<Article[]>(articleUrl)
  }

  deleteArticle(id:string):Observable<Article>{
    return this.http.delete<Article>(articleUrl+'/'+id, {
      headers: {
        authorization: 'Bearer ' + this.user.getUserDetails().token
      }
    })
  }

  getArticle(id):Observable<Article>{
   return this.http.get<Article>(articleUrl+'/'+id, {
    headers: {
      authorization: 'Bearer ' + this.user.getUserDetails().token
    }
  })
  }

  editArticle(id,data): Observable<Article>{
    
    return this.http.put<Article>(articleUrl+'/'+id,data, {
      headers: {
        authorization: 'Bearer ' + this.user.getUserDetails().token
      }
    })
  }

  getGeneralArticles():Observable<Article[]>{
    return this.http.get<Article[]>(articleUrl+'/general')
  }

  getSportsArticles():Observable<Article[]>{
    return this.http.get<Article[]>(articleUrl+'/sports')
  }
}
