import { Injectable } from '@angular/core';
import * as io from 'socket.io-client';
import { Observable } from 'rxjs';

//Models
import { User } from 'src/app/models/user.model';

@Injectable({
  providedIn: 'root',
})
export class WebsocketService {
  socket: any;
  readonly socket_URI: string = 'http://localhost:3000/';
  constructor() {
    this.socket = io(this.socket_URI);
  }

  // S ==> C
  //listen()
  listen(eventName: String) {
    return new Observable((subscriber) => {
      this.socket.on(eventName, (data) => {
        subscriber.next(data);
      });
    });
  }
  //C => S
  //emit()
  emit(eventName: String, data: any) {
    this.socket.emit(eventName, data);
  }
}
