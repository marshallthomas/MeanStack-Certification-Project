import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

const contactUrl = 'http://localhost:3000/contact'

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  constructor(private http: HttpClient) { }

  addQuery(data){
    return this.http.post(contactUrl, data);
  }
}
