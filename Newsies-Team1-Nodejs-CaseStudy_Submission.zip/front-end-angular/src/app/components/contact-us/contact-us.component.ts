import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { ContactService } from 'src/app/services/contact.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {

  contactForm: FormGroup

  constructor(private builder: FormBuilder, private route: Router, private contactService: ContactService) { }

  ngOnInit(): void {
    this.contactForm = this.builder.group({
      email: ['', Validators.required],
      query: ['', Validators.required]
    })
  }

  handleSubmit() {
    console.log('Inside Submit')
    this.contactService.addQuery(this.contactForm.value).subscribe(() => {

      alert('Your Query Has been added')
      this.route.navigate(['/contactus'])
    })
  }

}
