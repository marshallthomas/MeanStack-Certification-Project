import { Component, OnInit } from '@angular/core';
import {Article} from 'src/app/models/article.model'
import {ArticlesService} from 'src/app/services/articles.service'
import {MsgService} from 'src/app/services/msg.service'

@Component({
  selector: 'app-articlelist',
  templateUrl: './articlelist.component.html',
  styleUrls: ['./articlelist.component.css']
})
export class ArticlelistComponent implements OnInit {

  articles:Article[]=[]
  query=""
  constructor(private articleService:ArticlesService,private msgService:MsgService) { }

  ngOnInit(): void {
    this.fetchArticles()
    this.msgService.getMsg().subscribe(()=>{
      this.fetchArticles()
    })
    console.log(this.query)
  }

  fetchArticles(){
    this.articleService.getArticles().subscribe((data: Article[]) => {
      
      this.articles=data
    })
  }

  deleteArticles(data){
    var result=confirm("Are you sure you want to delete article:")
    if(result){
    this.articleService.deleteArticle(data._id).subscribe(()=>{
      this.msgService.sendMsg({msg: 'Article Removed!'})
    })
  }
  }
}
