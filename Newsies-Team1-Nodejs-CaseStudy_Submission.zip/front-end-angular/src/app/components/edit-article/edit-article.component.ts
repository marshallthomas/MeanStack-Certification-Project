import { Component, OnInit } from '@angular/core';
import {Article} from 'src/app/models/article.model'
import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import {Router, ActivatedRoute } from '@angular/router';
import {ArticlesService} from 'src/app/services/articles.service'
import {MsgService} from 'src/app/services/msg.service'
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-edit-article',
  templateUrl: './edit-article.component.html',
  styleUrls: ['./edit-article.component.css']
})
export class EditArticleComponent implements OnInit {

  articleForm:FormGroup;
  article: Article=null
  constructor(private route:Router,private activatedRoute:ActivatedRoute,private articleService:ArticlesService,private builder: FormBuilder,private msgService:MsgService,private datePipe: DatePipe) { }

  ngOnInit(): void {
    console.log("we got the data")
    this.articleForm=this.builder.group({
      title: ['',Validators.required],
      description: ['',Validators.required],
      url: ['',Validators.required],
      url_image: ['',Validators.required],
      category:['',Validators.required],
      published_at:new Date().toDateString() + ' ' +new Date().toLocaleTimeString(),
     
    })
    console.log("hello world")
    this.getData()
   
    this.msgService.getMsg().subscribe(()=>{
      this.articleForm=this.builder.group({
        title: [this.article.title,Validators.required],
        description: [this.article.description,Validators.required],
        url: [this.article.url,Validators.required],
        url_image: [this.article.url_image,Validators.required],
        category:[this.article.category,Validators.required],
        published_at: this.datePipe.transform(this.article.published_at,'yyyy-MM-dd hh:mm a')
       
      })
    })
    
  }

  getData(){
    const { id } = this.activatedRoute.snapshot.params
    console.log("did we get this far")
    this.articleService.getArticle(id).subscribe((data)=>{
      this.article=data;
      console.log(data)
      this.msgService.sendMsg({msg: 'Values Added for Editing'})
    })

  }
  handleUpdate(){
    this.articleService.editArticle(this.article._id,this.articleForm.value).subscribe(()=>{
      alert('Values have been updated')
      this.route.navigate(['/display'])
    })
  }

}
