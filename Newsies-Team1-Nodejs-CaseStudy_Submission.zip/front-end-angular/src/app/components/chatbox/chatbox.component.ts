import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as uuid from 'uuid';

//Models
import { User } from 'src/app/models/user.model';

//Service
import { WebsocketService } from '../../services/websocket.service';

@Component({
  selector: 'app-chatbox',
  templateUrl: './chatbox.component.html',
  styleUrls: ['./chatbox.component.css'],
})
export class ChatboxComponent implements OnInit {
  chatMessages: any[] = [];
  user: User;
  username: String;
  userList: any[] = [];
  chatmessageForm: FormGroup;

  randomColor: string;

  constructor(
    private websocketservice: WebsocketService,
    private builder: FormBuilder
  ) {
    this.randomColor =
      '#' + ((Math.random() * 0xffffff) << 0).toString(16).padStart(6, '0');
    this.chatmessageForm = this.builder.group({
      message: ['', Validators.required],
    });

    if (localStorage.getItem('user') !== null) {
      this.user = JSON.parse(localStorage.getItem('user'));
      this.username = this.user.name;
    } else {
      this.username = 'Guest - ' + uuid.v4();
      this.user = null;
    }

    console.log(this.username);
    let usermodel = {
      username: this.username,
      color: this.randomColor,
    };
    this.websocketservice.emit('username', usermodel);
    this.userList.push(this.username);
    /*
    this.websocketservice.listen('initialize chat msgs').subscribe((data) => {
      let temp = {
        msg: { message: this.username + ' has Just Entered!' },
        username: 'Chat-Bot',
        color: '#9c9c9c',
        date: this.getDate(),
        time: this.timeSent(),
      };
      // this.chatMessages.push(temp);
      this.websocketservice.emit('entermsg', temp);
    });
*/
    this.websocketservice.listen('chatmessages').subscribe((data: any) => {
      this.chatMessages = data;
    });
    this.websocketservice
      .listen('get previous chats')
      .subscribe((data: any) => {
        this.chatMessages.push(data);
      });
  }

  ngOnInit(): void {
    this.websocketservice.listen('userlist').subscribe((data: any[]) => {
      this.userList = [];
      //this.userList.push(this.username);
      for (let i = 0; i < data.length; i++) {
        this.userList.push(data[i]);
      }
    });

    this.websocketservice.listen('updatelist').subscribe((data: any) => {
      this.userList = data;
    });
  }

  timeSent() {
    let today = new Date();
    var time =
      today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();

    return time;
  }
  getDate() {
    let today = new Date();
    var date =
      today.getMonth() + '/' + today.getDay() + '/' + today.getFullYear();

    return date;
  }

  sendChatMessage() {
    console.log(this.chatmessageForm.value);
    let data = {
      msg: this.chatmessageForm.value,
      username: this.username,
      color: this.randomColor,
      date: this.getDate(),
      time: this.timeSent(),
    };
    this.websocketservice.emit('send msg', data);

    this.sendToChatBox();
    this.chatmessageForm.reset();
  }

  sendToChatBox() {
    this.websocketservice.listen('send to chat box').subscribe((data: any) => {
      this.chatMessages = data;
    });
  }
}
