import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms'
import {Router } from '@angular/router'
import { UserService } from 'src/app/services/user.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup
  constructor(
    private builder: FormBuilder,
    private userService: UserService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.registerForm = this.builder.group({
      name: ['', Validators.required],
      password: ['', Validators.required],
      email: ['', Validators.compose([Validators.required, Validators.email])],
      admin: ['', Validators.required]
    })
  }
  handleSubmit(){
  console.log("registering")
  this.userService.register(this.registerForm.value).subscribe((data) =>{
    this.router.navigate(['/login'])
  }, (err) =>{
    console.log(err)
  })
  }

}
