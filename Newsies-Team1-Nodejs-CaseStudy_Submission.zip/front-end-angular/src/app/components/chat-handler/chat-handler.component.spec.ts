import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatHandlerComponent } from './chat-handler.component';

describe('ChatHandlerComponent', () => {
  let component: ChatHandlerComponent;
  let fixture: ComponentFixture<ChatHandlerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChatHandlerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChatHandlerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
