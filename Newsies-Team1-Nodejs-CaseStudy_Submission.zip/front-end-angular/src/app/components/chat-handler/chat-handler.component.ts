import { Component, OnInit, HostListener } from '@angular/core';

@Component({
  selector: 'app-chat-handler',
  templateUrl: './chat-handler.component.html',
  styleUrls: ['./chat-handler.component.css']
})
export class ChatHandlerComponent implements OnInit {
  chatting=false
  constructor() { }

  ngOnInit(): void {
  }
  toggleChat(){
    this.chatting=!this.chatting
  }
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(this.chatting=true)
      this.toggleChat()
}

}
