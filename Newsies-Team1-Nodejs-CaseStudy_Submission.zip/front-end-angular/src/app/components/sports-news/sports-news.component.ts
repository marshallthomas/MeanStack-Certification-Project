import { Component, OnInit } from '@angular/core';
import {Article} from 'src/app/models/article.model';
import {ArticlesService} from 'src/app/services/articles.service'
@Component({
  selector: 'app-sports-news',
  templateUrl: './sports-news.component.html',
  styleUrls: ['./sports-news.component.css']
})
export class SportsNewsComponent implements OnInit {

  articles: Article[]=[]
  constructor(private articleService:ArticlesService) { }

  ngOnInit(): void {
    this.fetchArticles()
  }

  fetchArticles(){
    this.articleService.getSportsArticles().subscribe((data)=>{
      this.articles=data
    })
  }
}
