import { Component, OnInit } from '@angular/core';
import {Article} from 'src/app/models/article.model';
import {ArticlesService} from 'src/app/services/articles.service'
import {WeatherService} from 'src/app/services/weather.service'

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  lng:any
  lat:any
  articles:Article[]=[]
  query=""
 weatherData={
   temp:'',
   name:'',
   sunrise:'',
   sunset:'',
   speed:'',
   humidity:'',
   country:'',
   date:new Date(),
   sunriseDate:new Date(),
   sunsetDate:new Date(),
   description:''
 }
  constructor(private articleService:ArticlesService,private weatherService:WeatherService) { }

  ngOnInit(): void {
    if(navigator){
    navigator.geolocation.getCurrentPosition(resp => {
    this.lng= resp.coords.longitude 
    this.lat= resp.coords.latitude
      this.weatherService.getWeatherData(this.lng,this.lat).subscribe((data)=>{
        this.weatherData.name=data.name
        this.weatherData.speed=data.wind.speed
        var d=new Date(data.sys.sunrise*1000).toLocaleTimeString()
        this.weatherData.sunrise=d+''
        var d2=new Date(data.sys.sunset*1000).toLocaleTimeString()
        this.weatherData.sunriseDate= new Date(data.sys.sunrise*1000)
        this.weatherData.sunsetDate= new Date(data.sys.sunset*1000)
        this.weatherData.sunset=d2+''
        this.weatherData.temp=((data.main.temp-273.15).toFixed(1))
        this.weatherData.humidity=data.main.humidity
        this.weatherData.country=data.sys.country
        this.weatherData.date=new Date()
        this.weatherData.description=data.weather[0].description
        // console.log(this.weatherData.sunriseDate)
        // console.log(this.weatherData.date)
        // console.log('dif:   '+(this.weatherData.date.getTime()-this.weatherData.sunsetDate.getTime()))
        // console.log('Name: '+ this.weatherData.name+ ' speed: '+ this.weatherData.speed+ ' sunrise:'+ this.weatherData.sunrise + ' sunset:'+this.weatherData.sunset + ' temp:'+this.weatherData.temp+ ' humidity:'+this.weatherData.humidity)
      },(err)=>{
        console.log('Error aala re baba')
      })
  })
    }
    this.fetchArticles()
  }

  fetchArticles(){
    this.articleService.getGeneralArticles().subscribe((data)=>{
      this.articles=data
      
    })
  }
}
