import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import {ArticlesService} from 'src/app/services/articles.service'
import {Router} from '@angular/router';

@Component({
  selector: 'app-addarticle',
  templateUrl: './addarticle.component.html',
  styleUrls: ['./addarticle.component.css']
})
export class AddarticleComponent implements OnInit {

  articleForm:FormGroup;
  constructor(private builder: FormBuilder,private articleService:ArticlesService,private route:Router) { }

  ngOnInit(): void {
    this.articleForm=this.builder.group({
      title: ['',Validators.required],
      description: ['',Validators.required],
      url: ['',Validators.required],
      url_image: ['',Validators.required],
      category:['',Validators.required],
      published_at:new Date().toDateString() + ' ' +new Date().toLocaleTimeString(),
     
    })
  }

  handleRegister(){
    this.articleService.addArticle(this.articleForm.value).subscribe(()=>{

      this.articleForm.reset({published_at:new Date().toDateString() + ' ' +new Date().toLocaleTimeString()})
      alert('Your Article Has been added')
      this.route.navigate(['/display'])
    })
    
  }
}
