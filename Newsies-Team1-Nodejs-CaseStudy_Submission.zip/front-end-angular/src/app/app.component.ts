import { Component, HostListener } from '@angular/core';
import { Router } from '@angular/router';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: [ './app.component.css' ]
})
export class AppComponent {
	constructor(private router: Router) {
		router.events.subscribe((val) => {
			if (this.chatting == true) this.toggleChat();
		});
	}
	chatting = false;
	title = 'front-end';
	toggleChat() {
		if (this.chatting === true) {
			window.location.reload();
		}
		this.chatting = !this.chatting;
	}
	@HostListener('document:keydown.escape', [ '$event' ])
	onKeydownHandler(event: KeyboardEvent) {
		if ((this.chatting = true)) this.toggleChat();
	}
}
